from brilliance.research_api import open_research_run
from brilliance import accelerator_api as api
from scipy.optimize import minimize
import numpy as np
import json, os, time
from pathlib import Path

NAMES=['Q1','Q2','Q3','Q4','B1K','B2K','B3K','R1K','R2K','R3K','QD34','B4K','L1','L2','L3','L4','LR','LQ','bump_weight','core_weight','theta1','theta2','reverse','core_share','outer_ratio','core_ratio']
BOUNDS=np.array([[.1,6.8],[-6.8,-.1],[.1,6.8],[-6.8,-.1],[.05,4.1],[-3.,3.],[-4.1,-.05],[.1,6.8],[.1,6.8],[.1,6.8],[-6.8,-.1],[-4.1,-.05],[.65,1.6],[.6,1.4],[.6,1.3],[.6,1.3],[.12,.32],[.16,.34],[.3,3.],[.3,3.],[.01,.04],[.01,.04],[.0003,.006],[.24,.42],[1.1,5.],[1.5,7.]])
NAMES+=['LQ3','LQ4','LQD','bpre','bmid','bpost','bendgap']
BOUNDS=np.vstack([BOUNDS,[[.16,.4],[.16,.4],[.16,.4],[.3,3.],[.3,3.],[.3,3.],[.3,3.]]])
# Same project's physical architecture, with geometry now optimized alongside optics.
def build(x):
    p=dict(zip(NAMES,map(float,x))); rows=[]
    def add(kind,name,L,**kw): rows.append(api.element(kind,name,L,**kw))
    def drift(name,L,role='gap'): add('DRIFT',name,L,design_role=role)
    def quad(name,key): add('KQUAD',name,p[{'Q3':'LQ3','Q4':'LQ4','QD34':'LQD'}.get(key,'LQ')],k1_m2=p[key],family=key)
    def bend(name,L,ang,k,group,role): add('SBEND',name,L,angle_rad=ang,k1_m2=k,physical_bend=group,design_role=role)
    def lgb(name,L,ang,k,ratio,reverse=False):
        weights=np.array([ratio,np.sqrt(ratio),1.]); weights=weights[::-1] if reverse else weights
        for j,w in enumerate(weights): bend(name+'_'+str(j+1),L/3,ang*w/sum(weights),k,name,'outer_LGB')
    def core(name,L,ang,k,half=False):
        rr=p['core_ratio']; h=ang/(L*(.7+.3*rr))
        bend(name+'_F1',.35*L,h*.35*L,k,name,'core_flank')
        bend(name+'_C',(.15 if half else .30)*L,h*rr*(.15 if half else .30)*L,0.,name,'core_high_field')
        if not half: bend(name+'_F2',.35*L,h*.35*L,k,name,'core_flank')
    drift('ID_LEFT',3.,'clear_user_straight'); drift('SERVICE_LEFT',.25,'services')
    quad('Q1','Q1'); drift('g01',.1); quad('Q2','Q2'); drift('g02',.1)
    lgb('B1',p['L1'],p['theta1'],p['B1K'],p['outer_ratio'])
    drift('b01',.1); add('KSEXT','S1L',.18,k2_m3=0.,family='S1'); drift('b02',.1)
    quad('Q3','Q3'); drift('b03',.1); add('KSEXT','S2L',.18,k2_m3=0.,family='S2'); drift('b04',.1)
    quad('Q4','Q4'); drift('b05',.1); add('KSEXT','S3L',.18,k2_m3=0.,family='S3'); drift('b06',.1)
    add('KOCT','OL',.12,k3_m4=0.,family='O'); drift('b07',.1)
    lgb('B2',p['L2'],p['theta2'],p['B2K'],p['outer_ratio'],True); drift('c01',.1)
    total=2*np.pi/32+6*p['reverse']-2*(p['theta1']+p['theta2'])
    t3=total*p['core_share']; t4=total*(1-2*p['core_share'])
    bend('R1',p['LR'],-p['reverse'],p['R1K'],'R1','reverse'); drift('c02',.1)
    core('B3',p['L3'],t3,p['B3K']); drift('c03',.1)
    bend('R2',p['LR'],-p['reverse'],p['R2K'],'R2','reverse'); drift('c04',.1)
    quad('QD34','QD34'); drift('c05',.1)
    bend('R3',p['LR'],-p['reverse'],p['R3K'],'R3','reverse'); drift('c06',.1)
    core('B4',p['L4'],t4,p['B4K'],True)
    spare=810/64-sum(r['length_m'] for r in rows)
    gaps=[r for r in rows if r['fields'].get('design_role')=='gap']
    def weight(r):
        name=r['name']
        if name.startswith('b'):
            group='bpre' if name in ['b01','b02'] else 'bmid' if name in ['b03','b04'] else 'bpost' if name in ['b05','b06'] else 'bendgap'
            return p['bump_weight']*p[group]
        return p['core_weight'] if name.startswith('c') else 1.
    ww=[weight(r) for r in gaps]
    for r,w in zip(gaps,ww): r['length_m']+=spare*w/sum(ww)
    b=[]
    for r in reversed(rows):
        z=json.loads(json.dumps(r)); z['name']=r['name']+'_M'; z['fields']['mirror_of']=r['name']; b.append(z)
    return rows+b

def make_evaluator():
    jt=api.jutrack(); ed=None
    def evaluate(task):
        nonlocal ed
        x0=np.array(task['x']); low=BOUNDS[:,0]; span=BOUNDS[:,1]-low
        if ed is None:
            cell=api.periodic_cell(title='radiation refinement',energy_gev=3.5,elements=build(x0),source=__file__,intended_repetitions=32)
            ed=api.build_jutrack_editor(cell)
        cache={}; calls=0; history=[]; best=None
        def measured_chrom(rows):
            ed.sync_rows(rows)
            natural=np.asarray(jt.getchrom(ed.lattice,energy=3.5e9),float)*32
            response=[]
            for fam in ['S1','S2','S3']:
                pair=[]
                for sign in [1.,-1.]:
                    trial=json.loads(json.dumps(rows))
                    for r in trial:
                        if r['fields'].get('family')==fam: r['k2_m3']=sign*100.
                    ed.sync_rows(trial)
                    pair.append(np.asarray(jt.getchrom(ed.lattice,energy=3.5e9),float)*32)
                response.append((pair[0]-pair[1])/200.)
            response=np.array(response).T
            k=np.linalg.lstsq(response,np.array([5.,5.])-natural,rcond=None)[0]
            ed.sync_rows(rows)
            return {'natural_ring':natural.tolist(),'response_per_k2_m3':response.tolist(),'k2_m3':k.tolist(),'singular_values':np.linalg.svd(response)[1].tolist()}
        def calc(u):
            nonlocal calls,best
            key=np.asarray(u).tobytes()
            if key in cache: return cache[key]
            calls+=1; x=low+np.asarray(u)*span; rows=build(x)
            n=ed.evaluate_candidate(rows,energy_gev=3.5,periods=32,include_profile=True)
            lin=n['linear_optics']; rad=n['radiation']; good=bool(n['passed'])
            if good:
                prof={t['name']:t for t in lin['twiss_profile']}
                sites=[prof[s] for s in ['S1L','S2L','S3L']]
                core=[t for t in lin['twiss_profile'] if t['name'].startswith(('B3','B4'))]
                ds=np.array([t['Dx'] for t in sites]); dc=max(abs(t['Dx']) for t in core)
                b=lin['boundary_optics']; eps=rad['emittance_pm']
                ch=measured_chrom(rows); n['chromatic_screen']=ch
                kk=np.asarray(ch['k2_m3'])/640.
                obj=task.get('emittance_weight',1.)*np.log(eps/30.)+.12*np.sum(kk**2)+.02*np.sum(np.abs(ch['natural_ring']))/300.
                eq=np.array([b['Dx_m']/.03])
                cs=[(b['beta_x_m']-2.)/10.,(15.-b['beta_x_m'])/10.,(b['beta_y_m']-1.5)/10.,(12.-b['beta_y_m'])/10.,(45.-lin['maximum_beta_m'])/45.,rad['Jz']-.3,(min(ds)-.03)/.03,(.8*max(ds)-dc)/.03,(sites[0]['beta_y']-3.)/10.,(sites[1]['beta_x']-3.)/10.]
                cs+=list(1.-kk**2)
                cs+=[(task.get('eps_cap',60.)-eps)/30.,(1.998-abs(lin['trace_x'])),(1.998-abs(lin['trace_y']))]
            else:
                obj=100.+max(abs(lin['trace_x'])-1.9,0)**2+max(abs(lin['trace_y'])-1.9,0)**2
                eq=np.array([10.]); cs=[-10.]*16
            fields=[abs(r.get('angle_rad',0.)/r['length_m']*3.5/.299792458) for r in rows if r['kind']=='SBEND']
            gaps=[r['length_m'] for r in rows if r['fields'].get('design_role')=='gap']
            outer=[abs(r.get('angle_rad',0.)/r['length_m']*3.5/.299792458) for r in rows if r['fields'].get('design_role')=='outer_LGB']
            cs+= [(min(gaps)-.1),3.2-max(fields),1.-max(outer)]
            cs=np.array(cs); feasible=good and max(abs(eq))<1e-5 and min(cs)>-1e-5
            if feasible and (best is None or rad['emittance_pm']<best['native']['radiation']['emittance_pm']):
                best={'x':x.tolist(),'native':n,'objective':float(obj),'eq':eq.tolist(),'constraints':cs.tolist(),'calls':calls}
                history.append({'calls':calls,'emittance_pm':rad['emittance_pm'],'objective':float(obj)})
            ans=(obj,eq,cs,n); cache[key]=ans
            if len(cache)>90: cache.pop(next(iter(cache)))
            return ans
        u0=np.clip((x0-low)/span,1e-8,1-1e-8)
        initial=calc(u0)
        fit=minimize(lambda u:calc(u)[0],u0,method='SLSQP',bounds=[(0.,1.)]*len(x0),constraints=[{'type':'eq','fun':lambda u:calc(u)[1]},{'type':'ineq','fun':lambda u:calc(u)[2]}],options={'maxiter':task.get('maxiter',140),'ftol':2e-7,'eps':2e-6})
        end=calc(fit.x); x=low+fit.x*span
        final={'x':x.tolist(),'native':end[3],'objective':float(end[0]),'eq':end[1].tolist(),'constraints':end[2].tolist()}
        selected=best if best is not None else final
        (Path(os.environ['BRILLIANCE_RUN_OUTPUT'])/('pre_chrom_%03d.json'%task['id'])).write_text(json.dumps({'selected':selected,'final':final,'history':history,'calls':calls},indent=2))
        def chrom(): return np.array(jt.getchrom(ed.lattice,energy=3.5e9),dtype=float)*32
        # Measured native chromatic response, not a beta*D proxy. k2 is calibrated by perturbing actual elements.
        if selected['native']['passed']:
            rows=selected['native']['elements']; ed.sync_rows(rows)
            ch=measured_chrom(rows); response=np.array(ch['response_per_k2_m3']); k=np.array(ch['k2_m3'])
            corrected=json.loads(json.dumps(rows))
            for iteration in range(3):
                for r in corrected:
                    if r['kind']=='KSEXT': r['k2_m3']=float(k[['S1','S2','S3'].index(r['fields']['family'])])
                ed.sync_rows(corrected); actual=chrom()
                if max(abs(actual-5.))<1e-5: break
                if iteration<2: k+=np.linalg.lstsq(response,5.-actual,rcond=None)[0]
            selected['chromatic']={**ch,'k2_m3':k.tolist(),'corrected_ring':actual.tolist(),'corrected_elements':corrected}
        return {'id':task['id'],'selected':selected,'best_feasible':best is not None,'final':final,'initial_emittance_pm':initial[3]['radiation']['emittance_pm'] if initial[3]['passed'] else None,'success':bool(fit.success),'message':str(fit.message),'iterations':fit.nit,'calls':calls,'history':history}
    return evaluate

def main():
    run=open_research_run(); out=Path(os.environ['BRILLIANCE_RUN_OUTPUT']); a=run.arguments
    tasks=[]
    for i,spec in enumerate(a['seeds']):
        seed=json.loads(Path(spec['path']).read_text())
        if 'selected' in seed: x=seed['selected']['x']
        else:
            old=seed['x']; x=old[:12]+old[14:]
        if len(x)==26: x=x+[x[17],x[17],x[17],1.,1.,1.,1.]
        assert len(x)==len(NAMES)
        tasks.append({'id':i,'x':x,'maxiter':a.get('maxiter',100),'emittance_weight':spec.get('emittance_weight',1.),'eps_cap':spec.get('eps_cap',60.)})
    (out/'tasks.json').write_text(json.dumps(tasks,indent=2)); (out/'knobs.json').write_text(json.dumps({'names':NAMES,'bounds':BOUNDS.tolist()},indent=2))
    def save(i,r,status):
        if r is not None: (out/('refined_%03d.json'%r['id'])).write_text(json.dumps(r,indent=2))
    t=time.time()
    if a.get('diagnose',False):
        results=[make_evaluator()(tasks[0])]; save(0,results[0],None)
    else:
        with run.parallel_evaluator(make_evaluator,workers=a.get('workers',8),on_result=save) as pool: results=pool(tasks)
    table=[]
    for r in results:
        s=r['selected']; n=s['native']; rad=n['radiation']; ch=s.get('chromatic',{})
        table.append({'id':r['id'],'initial_pm':r['initial_emittance_pm'],'emittance_pm':rad.get('emittance_pm') if rad else None,'linear_geometry_feasible':r['best_feasible'],'straight_Dx_m':n['linear_optics'].get('Dx_m'),'max_abs_k2_m3':max(map(abs,ch['k2_m3'])) if ch else None,'corrected_xi':ch.get('corrected_ring'),'iterations':r['iterations'],'message':r['message'],'calls':r['calls']})
    (out/'summary.json').write_text(json.dumps(table,indent=2)); print(json.dumps(table))
    run.finish(summary='Radiation-aware variable-geometry H7BA refinement and measured chromatic response; ring acceptance not tested.',data={'summary':table,'seconds':time.time()-t},tables=[{'title':'Variable-geometry refinement','rows':table}],request_satisfied=False,limitations=['Cell-scaled radiation, not full-ring validation.','Ideal magnets; no RF, errors or nonlinear acceptance tests.','Service allowance is provisional.'])

if __name__=='__main__': main()
