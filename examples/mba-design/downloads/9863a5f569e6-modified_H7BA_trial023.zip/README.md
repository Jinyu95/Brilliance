# Working ideal-ring candidate: refined trial 023
This package consolidates saved calculations; no beam-dynamics calculation was repeated.

## Exact replay
Load working_ring.json (lattice-1fc08f33061a8bf6, explicit 32-cell / 810 m ring) and set native NumIntSteps=40 on each element supporting it, as prescribed by tracking_settings.json. The lattice file alone does not prescribe the refined integrator setting. RF and radiation tracking are off. Do not substitute default-step results. The supplied optics and local acceptance arrays are saved JuTrack evidence; parameterized_geometry.py is a research builder, not a replacement for the exact post-correction rows.

## Scope
1024-turn tracking, 160 entrance/midpoint locations in one exactly repeated cell, 48 sampled momenta; local kicks use x=px=py=0 and y=1 micrometre before a momentum change, transported to the common straight-centre launch boundary. Tracking is through the complete explicit ring. The transverse position mesh is 0.25 mm horizontally and 0.125 mm vertically with zero momenta. 320 launch-phase/mixing rays use 13 radial scales. Connected means no missing survivor along sampled rays/momentum lines, or 4-neighbor adjacency on the position grid; it is not proof of continuum survival. Exact final arrays remain in the cited validation run and the 40-step files are included here.

The provisional 2 mm x 1 mm normalized-action ellipsoid failed: only scale 0.625 survived on every sampled ray. This is not an injector capture-efficiency specification. No errors, chamber aperture, RF capture, radiation tracking, insertion devices or collective effects were modeled. The separate core defocusing quadrupoles use equal mirror-paired nominal gradients; independent trims remain untested. The service allowance is 0.5 m per cell, not a completed equipment installation design. B1/B7 embedded focusing is positive but weak. Magnet fields are ideal piecewise-constant longitudinal profiles with zero finite-gap fringe model.

The saved radiation wrapper's energy_loss_per_turn_eV=-0.0 is NOT a validated physical energy loss and must not be used for RF design. Emittance, integrals, energy spread and positive damping partitions are recorded separately. Working-lattice selection does not certify the original request. Injection scheme, incident beam phase space and required capture efficiency are needed to assess transverse usefulness.

Sources: project correction run program-50a6bb70e2aadf221d2e; acceptance run program-5b4b9a1959422f716873. External context only: https://link.springer.com/article/10.1007/s41365-021-00974-z (HEPS swap-out, not project evidence).
