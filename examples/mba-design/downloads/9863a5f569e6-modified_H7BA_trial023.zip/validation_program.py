from brilliance.research_api import open_research_run
from brilliance import accelerator_api as api
from pathlib import Path
from scipy.ndimage import label
import numpy as np
import os, json, time

def dump(p,o): p.write_text(json.dumps(o,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else float(x)))
def interval(v,f):
    m=int(np.argmin(abs(v))); lo=hi=m
    if not f[m]: return [0.,0.]
    while lo>0 and f[lo-1]: lo-=1
    while hi+1<len(v) and f[hi+1]: hi+=1
    return [float(v[lo]),float(v[hi])]
def make_evaluator():
    jt=api.jutrack()
    def evaluate(t):
        out=Path(os.environ['BRILLIANCE_RUN_OUTPUT']); start=time.time(); tag=t['tag']; n=t['steps']
        rows=json.loads(Path(t['source']).read_text())['selected']['corrected_elements']; N=len(rows)
        cell=api.periodic_cell(title=tag+' cell',energy_gev=3.5,elements=rows,source=__file__,intended_repetitions=32)
        ring=api.cell_ring(title=tag+' explicit ring',energy_gev=3.5,cell=rows,periods=32,source=__file__)
        ec=api.build_jutrack_editor(cell); er=api.build_jutrack_editor(ring)
        for lat in [ec.lattice,er.lattice]:
            for e in lat:
                if hasattr(e,'NumIntSteps'): jt.set_field(e,'NumIntSteps',int(n))
        s=np.r_[0.,np.cumsum([r['length_m'] for r in rows])]
        metadata={'tag':tag,'steps':n,'source':t['source'],'ring_scope':'explicit 32-cell ring, 810 m, 3.5 GeV','rf':False,'radiation_tracking':False,'physical_aperture':None,'errors':False}
        if t['kind']=='local':
            ds=np.array(t['deltas']); states=[]; pre=[]; sites=[]
            for site in t['sites']:
                j=site//2; frac=.5*(site%2); lat=ec.lattice[j:]
                if frac:
                    e=jt.deepcopy_element(ec.lattice[j]); jt.set_field(e,'len',rows[j]['length_m']*(1-frac))
                    if rows[j]['kind']=='SBEND':
                        assert float(e.e1)==0 and float(e.e2)==0, 'Nonzero edges need explicit physical interface handling'
                        jt.set_field(e,'angle',rows[j]['angle_rad']*(1-frac))
                    if hasattr(e,'NumIntSteps'): jt.set_field(e,'NumIntSteps',max(1,int(n*(1-frac))))
                    # Disable only the artificial midpoint entrance; preserve the physical exit.
                    # Exact intact-versus-half-map probes are archived in program-7e1da17e6dd7249b7790.
                    for fld in ['FringeQuadEntrance','FringeBendEntrance']:
                        if hasattr(e,fld): jt.set_field(e,fld,0)
                    lat=[e]+ec.lattice[j+1:]
                rr=np.zeros((len(ds),6)); rr[:,2]=1e-6; rr[:,5]=ds
                b=jt.Beam(rr,energy=3.5e9); jt.linepass(lat,b); f=np.asarray(b.r,float)
                pre.extend(((~np.asarray(b.lost_flag,bool).reshape(-1))&np.all(np.isfinite(f),axis=1)).tolist()); states.append(f)
                sites.append({'site':site,'element':rows[j]['name'],'fraction':frac,'s_m':float(s[j]+frac*rows[j]['length_m'])})
            state=np.vstack(states); initial=np.asarray(pre,bool); metadata.update(sites=sites,delta=ds,vertical_seed_m=1e-6)
        else:
            xs=np.linspace(-.004,.004,33); ys=np.linspace(-.00175,.00175,29); xx,yy=np.meshgrid(xs,ys)
            grid=np.zeros((xx.size,6)); grid[:,0]=xx.ravel(); grid[:,2]=yy.ravel()
            # Independent betatron phases at the straight centre: small-amplitude action ellipsoid probe.
            bx=9.6275969125; by=1.5014700888
            phase=np.arange(8)*2*np.pi/8; mixing=np.linspace(0,np.pi/2,5); scales=np.arange(0.,1.51,.125)
            rays=[]; rr=[]
            for mix in mixing:
                for px in phase:
                    for py in phase:
                        rays.append([float(mix),float(px),float(py)])
                        for q in scales:
                            ax=.002*q*np.cos(mix); ay=.001*q*np.sin(mix)
                            rr.append([ax*np.cos(px),-ax/bx*np.sin(px),ay*np.cos(py),-ay/by*np.sin(py),0.,0.])
            state=np.vstack([grid,np.array(rr)]); initial=np.ones(len(state),bool)
            metadata.update(x_m=xs,y_m=ys,grid_shape=xx.shape,grid_count=len(grid),ray_parameters=rays,radial_scales=scales,nominal_position_semiaxes_m=[.002,.001],launch_beta_m=[bx,by],launch_alpha_approximation=0.)
        state[~initial]=0.; dump(out/(tag+'_launch.json'),dict(metadata,initial_coordinates=state,initial_valid=initial))
        beam=jt.Beam(state,energy=3.5e9); previous=0; reports=[]
        for turns in t['turns']:
            jt.ringpass(er.lattice,beam,int(turns-previous)); previous=turns
            final=np.asarray(beam.r,float); alive=(~np.asarray(beam.lost_flag,bool).reshape(-1))&np.all(np.isfinite(final),axis=1)&initial
            rep={'turns':turns,'seconds':time.time()-start,'survived':alive}
            if t['kind']=='local':
                mask=alive.reshape(len(t['sites']),len(ds)); intervals=np.array([interval(ds,f) for f in mask])
                rep.update(connected_intervals=intervals,worst_minus_pct=float(100*max(intervals[:,0])),worst_plus_pct=float(100*min(intervals[:,1])))
            else:
                g=len(grid); mask=alive[:g].reshape(xx.shape); labs,_=label(mask); origin=(len(ys)//2,len(xs)//2); conn=labs==labs[origin] if labs[origin] else np.zeros_like(mask)
                raysmask=alive[g:].reshape(len(rays),len(scales)); radial=[]
                for flags in raysmask:
                    count=0
                    while count<len(flags) and flags[count]: count+=1
                    radial.append(float(scales[count-1]) if count else 0.)
                rep.update(connected=conn,x_interval_mm=(np.array(interval(xs,mask[len(ys)//2]))*1e3).tolist(),y_interval_mm=(np.array(interval(ys,mask[:,len(xs)//2]))*1e3).tolist(),connected_area_mm2=float(conn.sum()*(xs[1]-xs[0])*(ys[1]-ys[0])*1e6),radial_connected_scales=radial,minimum_phase_space_scale=min(radial))
            reports.append(rep); dump(out/(tag+'_checkpoint.json'),dict(metadata,reports=reports))
            print(json.dumps({'tag':tag,'turns':turns,'survivors':int(sum(alive)),'total':len(alive),'seconds':time.time()-start}),flush=True)
        dump(out/(tag+'_final.json'),dict(metadata,reports=reports,final_coordinates=final))
        return dict(metadata,reports=reports)
    return evaluate

def main():
    run=open_research_run(); a=run.arguments; out=Path(os.environ['BRILLIANCE_RUN_OUTPUT']); tasks=[]
    for steps in a.get('steps',[20,40]):
        sites=a.get('sites',list(range(160))); chunks=np.array_split(sites,a.get('local_chunks',3))
        for i,ch in enumerate(chunks): tasks.append(dict(a,kind='local',tag='local_n%d_%d'%(steps,i),steps=steps,sites=ch.tolist()))
        if a.get('transverse',True): tasks.append(dict(a,kind='transverse',tag='transverse_n%d'%steps,steps=steps))
    dump(out/'tasks.json',tasks)
    if a.get('serial',False): results=[make_evaluator()(t) for t in tasks]
    else:
        with run.parallel_evaluator(make_evaluator,workers=min(len(tasks),6)) as pool: results=pool(tasks)
    summary=[]
    for n in a.get('steps',[20,40]):
        local=[r for r in results if r['steps']==n and 'sites' in r]; trans=[r for r in results if r['steps']==n and 'grid_count' in r]
        for i,turns in enumerate(a['turns']):
            row={'steps':n,'turns':turns,'site_count':sum(len(r['sites']) for r in local),'worst_minus_pct':max(r['reports'][i]['worst_minus_pct'] for r in local),'worst_plus_pct':min(r['reports'][i]['worst_plus_pct'] for r in local)}
            if trans:
                for k in ['x_interval_mm','y_interval_mm','connected_area_mm2','minimum_phase_space_scale']: row[k]=trans[0]['reports'][i][k]
            summary.append(row)
    dump(out/'summary.json',summary); print(json.dumps(summary))
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    levels=a.get('steps',[20,40]); fig,axs=plt.subplots(len(levels),3,figsize=(15,4*len(levels)),squeeze=False)
    for ii,n in enumerate(levels):
        local=[r for r in results if r['steps']==n and 'sites' in r]; trans=[r for r in results if r['steps']==n and 'grid_count' in r]
        ss=np.concatenate([[v['s_m'] for v in r['sites']] for r in local]); order=np.argsort(ss)
        for ti,turns in enumerate(a['turns']):
            intervals=np.vstack([r['reports'][ti]['connected_intervals'] for r in local])*100
            axs[ii,0].plot(ss[order],intervals[order,0],label=str(turns)+' turns'); axs[ii,0].plot(ss[order],intervals[order,1],color=axs[ii,0].lines[-1].get_color())
        for y in [-2,2]: axs[ii,0].axhline(y,color='k',ls='--')
        axs[ii,0].set(xlabel='s in representative cell [m]',ylabel='Connected local delta [%]',title='%d integration steps'%n); axs[ii,0].legend()
        if trans:
            r=trans[0]; last=r['reports'][-1]; g=r['grid_count']; mask=np.array(last['survived'][:g]).reshape(r['grid_shape']); conn=np.array(last['connected'])
            axs[ii,1].pcolormesh(np.array(r['x_m'])*1e3,np.array(r['y_m'])*1e3,mask.astype(int)+conn.astype(int),vmin=0,vmax=2,shading='nearest'); axs[ii,1].set(xlabel='x [mm]',ylabel='y [mm]',title='Connected position domain, %d turns'%last['turns'])
            for rep in r['reports']: axs[ii,2].plot(rep['radial_connected_scales'],label=str(rep['turns'])+' turns')
            axs[ii,2].axhline(1,color='k',ls='--'); axs[ii,2].set(xlabel='Launch phase/mixing ray index',ylabel='Connected action-radius scale',title='Nominal position scales: 2 mm x 1 mm'); axs[ii,2].legend()
    fig.tight_layout(); fig.savefig(out/'validation.png',dpi=160)
    run.finish(summary='Longer-turn and integrator-convergence acceptance validation of the refined trial 023 ring.',tables=[{'title':'Connected ideal acceptance validation','rows':summary}],plots=[out/'validation.png'],data={'summary':summary},request_satisfied=False,limitations=['Ideal fixed-energy dynamics, not RF capture or injection-efficiency validation.','Sampling is finite in position, momentum and launch phase.','No magnet errors, radiation tracking or vacuum chamber.','Native numerical step settings in launch records must accompany the physical candidate.','No working lattice selected.'])
if __name__=='__main__': main()
