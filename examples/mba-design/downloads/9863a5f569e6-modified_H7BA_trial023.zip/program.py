from brilliance.research_api import open_research_run
from brilliance import accelerator_api as api
from pathlib import Path
import json, os, shutil, hashlib, zipfile
import numpy as np

def dump(p,o):
    p.write_text(json.dumps(o,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else float(x)))

def main():
    run=open_research_run(); out=Path(os.environ['BRILLIANCE_RUN_OUTPUT'])
    root=run.workspace/'artifacts'/'programs'
    prep=root/'program-50a6bb70e2aadf221d2e'; val=root/'program-5b4b9a1959422f716873'
    co=root/'program-3449f0eaaf3cf8e33a0d'
    seed=json.loads((prep/'candidate.json').read_text())['selected']; rows=seed['corrected_elements']
    ring_data=json.loads((prep/'corrected_ring.json').read_text())
    corrections=json.loads((prep/'correction.json').read_text())['full_ring']
    summary=json.loads((val/'summary.json').read_text())
    # Saved-evidence audit and presentation only: no JuTrack numerical calls.
    assert ring_data['metadata']['ring_complete'] and len(ring_data['elements'])==32*len(rows)==2560
    for i,r in enumerate(ring_data['elements']):
        c=rows[i%80]
        for k in ['kind','length_m','angle_rad','k1_m2','k2_m3','k3_m4']: assert r[k]==c[k], (i,k)
        for k,v in c['fields'].items(): assert r['fields'][k]==v
    ledger={}
    for r in rows:
        role=r['fields'].get('design_role')
        category=role if role in ['clear_user_straight','services'] else 'arc'
        ledger[category]=ledger.get(category,0.)+r['length_m']
    L=sum(r['length_m'] for r in rows); angle=sum(r.get('angle_rad') or 0. for r in rows)
    assert abs(32*L-810)<1e-10 and abs(32*angle-2*np.pi)<1e-12
    assert ledger['clear_user_straight']==6. and ledger['services']==.5
    def physical(r):
        p=r['fields'].get('physical_bend'); mirror='mirror_of' in r['fields']
        if mirror and p in ['B1','B2','B3']: return {'B1':'B7','B2':'B6','B3':'B5'}[p]
        if mirror and p and p.startswith('R'): return p+'_right'
        return p
    groups={}
    for r in rows:
        if r['kind']=='SBEND': groups.setdefault(physical(r),[]).append(r)
    assert len(groups)==13 and len([k for k in groups if k.startswith('B')])==7
    for k in ['B1','B7']: assert all(r['k1_m2']>0 for r in groups[k])
    for k in ['B3','B4','B5']:
        c=[r for r in groups[k] if r['fields']['design_role']=='core_high_field']
        f=[r for r in groups[k] if r['fields']['design_role']=='core_flank']
        assert min(r['angle_rad']/r['length_m'] for r in c)>max(r['angle_rad']/r['length_m'] for r in f)
        assert all(r['k1_m2']<0 for r in f)
    quads=[r for r in rows if r['name'] in ['QD34','QD34_M']]
    assert len(quads)==2 and all(r['k1_m2']<0 for r in quads)
    assert sum(r['kind']=='KSEXT' for r in rows[:40])==sum(r['kind']=='KSEXT' for r in rows[40:])==3
    assert sum(r['kind']=='KOCT' for r in rows)==2
    brho=3.5/.299792458
    bends=[]
    for k,g in groups.items():
        bends.append({'module':k,'length_m':sum(r['length_m'] for r in g),'angle_mrad':1e3*sum(r['angle_rad'] for r in g),'segment_B_T':[brho*r['angle_rad']/r['length_m'] for r in g],'segment_K1_m2':[r['k1_m2'] for r in g]})
    families=[]
    for r in rows[:40]:
        if r['kind'] in ['KQUAD','KSEXT','KOCT']:
            k={'KQUAD':'k1_m2','KSEXT':'k2_m3','KOCT':'k3_m4'}[r['kind']]
            families.append({'name':r['name'],'length_m':r['length_m'],'strength_convention':k,'strength':r[k],'integrated_strength':r[k]*r['length_m'],'instances_per_cell':2})
    lin=corrections[1]['linear']; rad=corrections[1]['radiation']; ch=corrections[1]['chromaticity']
    prof=seed['native']['linear_optics']['twiss_profile']
    sext=[]
    for t in prof:
        if t['name'].startswith('S') and not t['name'].startswith('SERVICE'): sext.append(t)
    locals40=[json.loads((val/('local_n40_%d_final.json'%i)).read_text()) for i in range(3)]
    local_sites=[]
    for r in locals40:
        for i,site in enumerate(r['sites']):
            ints=r['reports'][-1]['connected_intervals'][i]
            local_sites.append(dict(site,minus_pct=100*ints[0],plus_pct=100*ints[1]))
    local_sites.sort(key=lambda x:x['site'])
    worst_minus=max(t['minus_pct'] for t in local_sites); worst_plus=min(t['plus_pct'] for t in local_sites)
    bottlenecks={'negative':[t for t in local_sites if t['minus_pct']==worst_minus], 'positive':[t for t in local_sites if t['plus_pct']==worst_plus]}
    trans=json.loads((val/'transverse_n40_final.json').read_text()); q=trans['reports'][-1]['minimum_phase_space_scale']
    ax,ay=np.array(trans['nominal_position_semiaxes_m'])*q
    geometric_invariants_nm=[ax**2/lin['beta_x_m']*1e9,ay**2/lin['beta_y_m']*1e9]
    audit={'lattice_id':ring_data['lattice_id'],'ring_elements_verified':2560,'cell_elements':80,'ring_circumference_m':32*L,'net_angle_rad':32*angle,'cell_ledger_m':ledger,'bend_modules':bends,'multipole_families':families,'launch_optics':lin,'radiation':rad,'chromaticity':ch,'sextupole_exit_optics':sext,'acceptance_summary':summary,'limiting_sites_40steps_1024turns':bottlenecks,'phase_space':{'sampled_position_semiaxes_mm':[ax*1e3,ay*1e3],'twoJ_semiaxes_nm':geometric_invariants_nm,'interpretation':'Finite phase/radial sampling of a normalized-action ellipsoid, NOT guaranteed continuous volume or capture efficiency.'},'not_used_as_energy_loss_measurement':rad.get('energy_loss_per_turn_eV'),'independent_QD_note':'Separate physical core quadrupoles, mirror-paired to the same nominal gradient; independent trim response not tested.'}
    dump(out/'audit.json',audit); dump(out/'cell_elements.json',rows)
    dump(out/'local_acceptance.json',local_sites)
    dump(out/'optics_profile.json',prof)
    dump(out/'integration_comparison.json',corrections)
    files=[(prep/'corrected_ring.json','working_ring.json'),(prep/'tracking_settings.json','tracking_settings.json'),(prep/'candidate.json','candidate_provenance.json'),(val/'validation.png','validation.png'),(co/'archived_geometry_builder.py','parameterized_geometry.py'),(val/'program.py','validation_program.py')]
    for src,dst in files: shutil.copyfile(src,out/dst)
    cofit=json.loads((co/'codesign_002.json').read_text())
    dump(out/'parameter_values.json',{'knobs':dict(zip(cofit['knob_names'],seed['x'])),'bounds':cofit['bounds'],'note':'Geometry x is provenance; exact final sextupoles/octupoles are in working_ring.json.'})
    dump(out/'manifest.json',{'files':[{'source':str(src),'copy':dst,'sha256':hashlib.sha256(src.read_bytes()).hexdigest()} for src,dst in files],'tracking_evidence_run':'program-5b4b9a1959422f716873','correction_evidence_run':'program-50a6bb70e2aadf221d2e','no_new_beam_dynamics':True,'working_lattice_selection_is_not_request_certification':True})
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(4,1,figsize=(12,12),sharex=True)
    ss=np.array([t['s_m'] for t in prof])
    axs[0].plot(ss,[t['beta_x'] for t in prof],label='beta x')
    axs[0].plot(ss,[t['beta_y'] for t in prof],label='beta y'); axs[0].set_ylabel('Beta [m]'); axs[0].legend()
    axs[1].plot(ss,np.array([t['Dx'] for t in prof])*1e3); axs[1].set_ylabel('Dx [mm]')
    s0=0.; colors={'SBEND':'tab:blue','KQUAD':'tab:orange','KSEXT':'tab:green','KOCT':'tab:red'}
    for r in rows:
        s1=s0+r['length_m']; role=r['fields'].get('design_role')
        if role in ['clear_user_straight','services']:
            for axp in axs: axp.axvspan(s0,s1,color='green' if role=='clear_user_straight' else 'gray',alpha=.08)
        if r['kind']=='SBEND': axs[2].plot([s0,s1],[brho*r['angle_rad']/r['length_m']]*2,color='tab:blue')
        if r['kind'] in colors:
            y=-1 if r['kind']=='SBEND' and r['angle_rad']<0 else 1
            axs[3].bar(s0,r['length_m']*0+ y,width=r['length_m'],align='edge',color=colors[r['kind']])
        s0=s1
    axs[2].set_ylabel('Dipole field [T]'); axs[3].set(ylabel='Magnet layout',xlabel='s in cell [m]',yticks=[],xlim=(0,L))
    fig.suptitle('Refined trial 023: saved 40-step optics and exact geometry\nGreen: clear user straight; gray: services. Profiles sampled at element boundaries.')
    fig.tight_layout(); fig.savefig(out/'optics_layout.png',dpi=160); plt.close(fig)
    requirements=[{'quantity':'Energy','value':3.5,'unit':'GeV','assessment':'fixed'}, {'quantity':'Circumference','value':32*L,'unit':'m','assessment':'closed, complete 32-cell ring'}, {'quantity':'Natural emittance','value':rad['emittance_pm'],'unit':'pm rad','assessment':'below 30; not near 20'}, {'quantity':'Chromaticity x','value':ch['chromaticity_x'],'unit':'1','assessment':'target +5'}, {'quantity':'Chromaticity y','value':ch['chromaticity_y'],'unit':'1','assessment':'target +5'}, {'quantity':'Worst negative local delta','value':worst_minus,'unit':'percent','assessment':'sampled >2 percent magnitude, narrow margin'}, {'quantity':'Worst positive local delta','value':worst_plus,'unit':'percent','assessment':'sampled >2 percent'}, {'quantity':'Connected zero-momenta area','value':trans['reports'][-1]['connected_area_mm2'],'unit':'mm2','assessment':'4-neighbor grid, not continuous volume'}, {'quantity':'Worst phase-space radius scale','value':q,'unit':'relative to 2 mm x 1 mm','assessment':'failed provisional scale 1; injector utility unresolved'}]
    (out/'README.md').write_text('''# Working ideal-ring candidate: refined trial 023
This package consolidates saved calculations; no beam-dynamics calculation was repeated.

## Exact replay
Load working_ring.json (lattice-1fc08f33061a8bf6, explicit 32-cell / 810 m ring) and set native NumIntSteps=40 on each element supporting it, as prescribed by tracking_settings.json. The lattice file alone does not prescribe the refined integrator setting. RF and radiation tracking are off. Do not substitute default-step results. The supplied optics and local acceptance arrays are saved JuTrack evidence; parameterized_geometry.py is a research builder, not a replacement for the exact post-correction rows.

## Scope
1024-turn tracking, 160 entrance/midpoint locations in one exactly repeated cell, 48 sampled momenta; local kicks use x=px=py=0 and y=1 micrometre before a momentum change, transported to the common straight-centre launch boundary. Tracking is through the complete explicit ring. The transverse position mesh is 0.25 mm horizontally and 0.125 mm vertically with zero momenta. 320 launch-phase/mixing rays use 13 radial scales. Connected means no missing survivor along sampled rays/momentum lines, or 4-neighbor adjacency on the position grid; it is not proof of continuum survival. Exact final arrays remain in the cited validation run and the 40-step files are included here.

The provisional 2 mm x 1 mm normalized-action ellipsoid failed: only scale 0.625 survived on every sampled ray. This is not an injector capture-efficiency specification. No errors, chamber aperture, RF capture, radiation tracking, insertion devices or collective effects were modeled. The separate core defocusing quadrupoles use equal mirror-paired nominal gradients; independent trims remain untested. The service allowance is 0.5 m per cell, not a completed equipment installation design. B1/B7 embedded focusing is positive but weak. Magnet fields are ideal piecewise-constant longitudinal profiles with zero finite-gap fringe model.

The saved radiation wrapper's energy_loss_per_turn_eV=-0.0 is NOT a validated physical energy loss and must not be used for RF design. Emittance, integrals, energy spread and positive damping partitions are recorded separately. Working-lattice selection does not certify the original request. Injection scheme, incident beam phase space and required capture efficiency are needed to assess transverse usefulness.

Sources: project correction run program-50a6bb70e2aadf221d2e; acceptance run program-5b4b9a1959422f716873. External context only: https://link.springer.com/article/10.1007/s41365-021-00974-z (HEPS swap-out, not project evidence).
''')
    for f in ['local_n40_0_final.json','local_n40_1_final.json','local_n40_2_final.json','transverse_n40_final.json']:
        shutil.copyfile(val/f,out/f)
    package=out/'modified_H7BA_trial023.zip'
    with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED) as z:
        for p in out.iterdir():
            if p.suffix in ['.json','.md','.png','.py'] and p.name!='result.json': z.write(p,p.name)
    print(json.dumps({'lattice_id':ring_data['lattice_id'],'requirements':requirements,'phase_space':audit['phase_space'],'limiting_sites':bottlenecks,'ledger':ledger,'bend_modules':bends,'multipole_families':families}))
    candidate=api.load_lattice(prep/'corrected_ring.json')
    run.finish(summary='Saved-evidence audit and qualified working selection of refined trial 023 complete ring; transverse usefulness remains injector-dependent.',candidate_lattice=candidate,use_as_working_lattice=True,request_satisfied=False,data={'lattice_id':ring_data['lattice_id'],'audit_file':str(out/'audit.json'),'no_new_beam_dynamics':True,'validation_run_id':'program-5b4b9a1959422f716873'},tables=[{'title':'Requirements and measured scope','rows':requirements},{'title':'Integration and turn comparison','rows':summary},{'title':'Finite multipole strengths (mirror-paired nominal settings)','rows':families}],plots=[out/'optics_layout.png',out/'validation.png'],downloads=[package],methods=['Audit and plotting of this project saved JuTrack outputs; no repeated tracking.'],limitations=['Original transverse usefulness requirement unresolved; larger provisional phase-space target failed.','Ideal RF-off/error-free fixed-momentum lattice only; not injection validation.','Use exact ring plus native 40-step tracking settings.','Selection is a working candidate, not certification.'])

if __name__=='__main__': main()
